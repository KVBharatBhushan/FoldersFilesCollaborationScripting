﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$ListName="Reports Archive"
$FolderServerRelativeURL = "/sites/S022-013-IS/BoxMigration/Reports Archive/Created Folder"


$foldercount=$($args.count)

write-host "There are a total of $($args.count) arguments" 
$UserAccount = $args[0]
  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -Useweblogin
 
#Get the Folder from URL
$Folder = Get-PnPFolder -Url $FolderServerRelativeURL
     
#Set Permission to Folder
Set-PnPListItemPermission -List $ListName -Identity $Folder.ListItemAllFields -User $UserAccount -AddRole 'Contribute'