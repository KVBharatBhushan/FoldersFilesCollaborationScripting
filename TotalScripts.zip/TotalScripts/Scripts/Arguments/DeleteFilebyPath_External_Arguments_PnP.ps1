﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
#$FileRelativeURL ="/sites/S022-013-IS/BoxMigration/Reports Archive/SpecialDemo_SpecialDemo_Demo_dummyfile704.pdf" #arg
 

$foldercount=$($args.count)

write-host "There are a total of $($args.count) arguments" 
 
Try {
    #Connect to PNP Online
    Connect-PnPOnline -Url $SiteURL -UseWebLogin
      For($i = 0; $i -lt $args.count; $i++)
    {
    
    $FileRelativeURL=$args[$i]
    Write-Host $FileRelativeURL
    #Try to GetRelativeURL File
    $File = Get-PnPFile -Url $FileRelativeURL -ErrorAction SilentlyContinue
    Write-Host $FileRelativeURL
    Write-Host $File
    If($File)
    { 
        #Delete the File
        Remove-PnPFile -ServerRelativeUrl $FileRelativeURL -Force
        Write-Host -f Green "File $FileRelativeURL deleted successfully!"
    }
    
    Else
    {
        Write-Host -f Yellow "Could not Find File at $FileRelativeURL"
    }
    }
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}


