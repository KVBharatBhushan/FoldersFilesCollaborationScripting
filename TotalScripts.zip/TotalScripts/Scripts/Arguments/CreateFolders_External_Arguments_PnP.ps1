﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
#$CSVFilePath = "D:\TempFolders\Folders_SameLib.csv"
$foldercount=$($args.count)

write-host "There are a total of $($args.count) arguments" 

$LibraryName = "/Reports Archive"
 
Try {
    #Connect to PnP Online
    Connect-PnPOnline -Url $SiteURL -UseWebLogin
    $Web = Get-PnPWeb
 
    #Get the Document Library and its site relative URL
    $Library = Get-PnPList -Identity $LibraryName -Includes RootFolder
    If($Web.ServerRelativeUrl -eq "/")
    {
        $LibrarySiteRelativeURL = $Library.RootFolder.ServerRelativeUrl
    }
    else
    {
        $LibrarySiteRelativeURL = $Library.RootFolder.ServerRelativeUrl.Replace($Web.ServerRelativeUrl,'')
    }
 
    #Get the CSV file
    $CSVFile = Import-Csv $CSVFilePath
  
    #Read CSV file and create document document library
    For($i = 0; $i -lt $args.count; $i++)
    {
        #Replace Invalid Characters from Folder Name, If any
        $FolderName = $($args[$i])
        write-host  $FolderName
        $FolderName = [RegEx]::Replace($FolderName, "[{0}]" -f ([RegEx]::Escape([String]'\"*:<>?/\|')), '_')
 
        #Frame the Folder Name
        $FolderURL = $LibrarySiteRelativeURL+"/"+$FolderName
 
        #Create Folder if it doesn't exist
        Resolve-PnPFolder -SiteRelativePath $FolderURL | Out-Null
        Write-host "Ensured Folder:"$FolderName -f Green
    }
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}