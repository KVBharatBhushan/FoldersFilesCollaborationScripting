﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$ListName="Reports Archive"
$FolderServerRelativeURL = "/sites/S022-013-IS/BoxMigration/Reports Archive/Created Folder"
   
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
  
#Grant folder permissions to SharePoint Group which should exist!
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -AddRole "Read" -Group "Box Migration Members"

