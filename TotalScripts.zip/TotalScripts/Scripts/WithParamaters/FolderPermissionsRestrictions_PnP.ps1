﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$ListName="Reports Archive"
$FolderServerRelativeURL = "/sites/S022-013-IS/BoxMigration/Reports Archive/Created Folder"
  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
 
#Set folder permissions - Add User
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -User "suresh.gade@sony.com" -AddRole "Full Control"
 
#To remove user, use: Set-PnPfolderPermission -List $ListName -identity $FolderSiteRelativePath -User "abcd.onmicrosoft.com" -RemoveRole "Edit"


