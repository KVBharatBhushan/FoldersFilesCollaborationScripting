﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$FileRelativeURL ="/sites/S022-013-IS/BoxMigration/Reports Archive/SpecialDemo_SpecialDemo_Demo_dummyfile704.pdf"
 

 
Try {
    #Connect to PNP Online
    Connect-PnPOnline -Url $SiteURL -UseWebLogin
     
    #Try to Get File
    $File = Get-PnPFile -Url $FileRelativeURL -ErrorAction SilentlyContinue
    If($File)
    {
        #Delete the File
        Remove-PnPFile -ServerRelativeUrl $FileRelativeURL -Force
        Write-Host -f Green "File $FileRelativeURL deleted successfully!"
    }
    Else
    {
        Write-Host -f Yellow "Could not Find File at $FileRelativeURL"
    }
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}


