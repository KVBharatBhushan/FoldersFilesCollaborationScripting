﻿#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$FileURL= "Reports Archive/Created Folder/newNAMEfile.txt"
$NewFileName ="Topdf.pdf" #Always include file extension
 
#Connect to PnP Online
#Connect-PnPOnline -Url $SiteURL -Credentials (Get-Credential)
Connect-PnPOnline -Url $SiteURL -UseWebLogin
 
#Rename the File
Rename-PnPFile -SiteRelativeUrl $FileURL -TargetFileName $NewFileName -Force


