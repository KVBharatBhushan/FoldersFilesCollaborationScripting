#Config Variables
$SiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"
$ListName="Reports Archive"
$FolderServerRelativeURL = "/sites/S022-013-IS/BoxMigration/Reports Archive/Extra Folderyy"
#$FolderServerRelativeURL = "/sites/S022-013-IS/BoxMigration/Reports Archive/Created Folder"
  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin

#To remove user, use:- -RemoveRole
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -User "suresh.gade@sony.com" -RemoveRole "Full Control"
 



