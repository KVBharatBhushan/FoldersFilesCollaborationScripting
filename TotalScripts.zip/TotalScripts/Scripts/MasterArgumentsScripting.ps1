﻿PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\CreateFolders_External_Arguments_PnP.ps1 'folderAAA' 'folderBBB'

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\FolderPermissions_SingleUserID_External_Arguments_PnP.ps1 "guruprasad.yellappa@sony.com"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\FolderPermissions_MultipleUserIDs_External_Arguments_PnP.ps1 "guruprasad.yellappa@sony.com" "suresh.gade@sony.com"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\RemoveFolderPermissions_MultipleUserIDs_External_Arguments_PnP.ps1 "guruprasad.yellappa@sony.com" "suresh.gade@sony.com"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\DeleteFilebyPath_External_Arguments_PnP.ps1 "'/sites/S022-013-IS/BoxMigration/Reports Archive/FolderD5/ExternalUser_Download.jpg'" "'/sites/S022-013-IS/BoxMigration/Reports Archive/FolderD5/FDD5/InvokeAnotherScript1.jpg'"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\DeleteLargeFolder_External_Arguments_PnP.ps1 "'/sites/S022-013-IS/BoxMigration/Reports Archive/FolderD12'" "'/sites/S022-013-IS/BoxMigration/Reports Archive/FolderA5/test/test2'"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\SimpleDownload_External_Argument_PnP.ps1 "'D:\Bharat\DemoLibFiles4'" "'/Reports Archive/Barry'"

PowerShell D:\Bharat\FolderManagement\Scripts\Arguments\SimpleUpload_IntoFolder_External_Argument_PnP.ps1 "'D:\Bharat\DemoLibFiles4'" "'/Reports Archive/Black/Test'"

