﻿Write-Host "Hello World!";

Write-Host "Invoking or Calling another PnP PS Script";

#D:\Bharat\FolderManagement\Scripts\WithParamaters\CreateFolder_PnP.ps1 'Extra Folderzzz' '/Reports Archive'

D:\Bharat\FolderManagement\Scripts\WithParamaters\CreateFolder_PnP.ps1


