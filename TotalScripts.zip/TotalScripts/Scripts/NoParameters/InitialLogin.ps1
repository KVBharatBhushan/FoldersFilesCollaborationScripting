﻿

$SharePointSiteURL = "https://sonyeur.sharepoint.com/sites/S022-013-IS/BoxMigration"  

Connect-PnPOnline -Url $SharePointSiteURL -UseWebLogin