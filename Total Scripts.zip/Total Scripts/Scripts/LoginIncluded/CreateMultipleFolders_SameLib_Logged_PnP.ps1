﻿#Config Variables

$CSVFilePath = "D:\PnPInput\FolderManagement\Folders_SameLib2.csv"

$Username = "###############"
$Password = '######'
$SiteCollection = "######################"

[SecureString]$SecurePass = ConvertTo-SecureString $Password -AsPlainText -Force
[System.Management.Automation.PSCredential]$PSCredentials = New-Object System.Management.Automation.PSCredential($Username, $SecurePass)
Connect-PnPOnline -Url $SiteCollection -Credentials $PSCredentials
  
Try {
    #Connect to PnP Online
    #Connect-PnPOnline -Url $SiteURL -UseWebLogin

 
    #Get the CSV file
    $CSVFile = Import-Csv $CSVFilePath
   
    #Read CSV file and create document document library
    ForEach($Row in $CSVFile)
    {
        #Create Folder if it doesn't exist
        Resolve-PnPFolder -SiteRelativePath $Row.FolderSiteRelativeURL | Out-Null
        Write-host "Ensured Folder:"$Row.FolderSiteRelativeURL -f Green

    }
    Disconnect-PnPOnline
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}


