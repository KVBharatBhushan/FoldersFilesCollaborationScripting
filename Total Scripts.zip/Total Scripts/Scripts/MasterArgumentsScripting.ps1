﻿PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\CreateFolders_External_Arguments_PnP.ps1 'folderAAA' 'folderBBB'

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\FolderPermissions_SingleUserID_External_Arguments_PnP.ps1 "user1@xxx.com"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\FolderPermissions_MultipleUserIDs_External_Arguments_PnP.ps1 "user1@xxx.com" "user2@xxx.com"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\RemoveFolderPermissions_MultipleUserIDs_External_Arguments_PnP.ps1 "user1@xxx.com" "user2@xxx.com"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\DeleteFilebyPath_External_Arguments_PnP.ps1 "'/####/#####/####/LibName/FolderName/xyz.jpg'" "'/####/#####/####/LibName/FolderName/FDD5/abc.jpg'"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\DeleteLargeFolder_External_Arguments_PnP.ps1 "'/####/#####/####/LibName/FolderD12'" "'/####/#####/####/LibName/ FolderName /subfoldername/sub-subfoldername '"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\SimpleDownload_External_Argument_PnP.ps1 "'D:\PnPInput\DemoLibFiles4'" "'/LibName/TestFolder'"

PowerShell D:\PnPInput\FolderManagement\Scripts\Arguments\SimpleUpload_IntoFolder_External_Argument_PnP.ps1 "'D:\PnPInput\DemoLibFiles4'" "'/LibName/TestFolder/TestSubFolder"
