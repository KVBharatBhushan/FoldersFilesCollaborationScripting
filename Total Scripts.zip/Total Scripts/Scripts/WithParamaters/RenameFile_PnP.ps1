﻿#Config Variables
$SiteURL = "#################"
$FileURL= "LibName/FolderName/xxx.txt"
$NewFileName ="newNAMEfile.txt" #Always include file extension
 
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
 
#Rename the File
Rename-PnPFile -SiteRelativeUrl $FileURL -TargetFileName $NewFileName -Force


