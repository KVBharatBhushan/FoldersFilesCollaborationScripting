#Config Variables
$SiteURL = "###########"
$ListName="LibName"
$FolderServerRelativeURL = "/#####/#####/######/LibName/FolderName"

  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin

#To remove user, use:- -RemoveRole
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -User "user@xxx.com" -RemoveRole "Full Control"
 



