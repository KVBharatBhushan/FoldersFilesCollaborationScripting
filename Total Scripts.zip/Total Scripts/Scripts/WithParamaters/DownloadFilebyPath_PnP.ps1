﻿#Config Variables
$SiteURL = "################"
$ListName="LibName"
$FileRelativeURL = "/###/########/#######/LibName/FolderName/abc.pdf"

$DownloadPath ="D:\PnPDownloads"
 
#Get Credentials to connect
#$Cred = Get-Credential
 
Try {
    #Connect to PNP Online
    Connect-PnPOnline -Url $SiteURL -Useweblogin
     
    #powershell download file from sharepoint online
    Get-PnPFile -Url $FileRelativeURL -Path $DownloadPath -AsFile
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}


