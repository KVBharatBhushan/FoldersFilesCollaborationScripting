﻿#Config Variables
$SharePointSiteURL = "######################"
$FolderName= "FolderName"
#$FolderName= args[0]
#$FolderName= ''

$RelativeURL= "/LibName"
#$RelativeURL= args[1]
#$RelativeURL= ''


 
Try {
    #Connect to PnP Online    
    #Connect-PnPOnline -Url $SharePointSiteURL -CurrentCredentials
    Connect-PnPOnline -Url $SharePointSiteURL -UseWebLogin
     
    #sharepoint online create folder powershell
    Add-PnPFolder -Name $FolderName -Folder $RelativeURL -ErrorAction Stop
    Write-host -f Green "New Folder '$FolderName' Added!"
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}


