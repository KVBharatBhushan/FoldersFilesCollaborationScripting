﻿#Config Variables
$SiteURL = "##################"
$ListName="LibName"
$FolderServerRelativeURL = "/#####/#####/#######/LibName/FolderName"
   
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
  
#Grant folder permissions to SharePoint Group which should exist!
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -AddRole "Read" -Group "Box Migration Members"

