﻿#Config Variables 
$SiteURL = "#############3" 
$LibURL= "LibName/" #For renaming Lib name
#$FolderURL= "LibName/FolderName" #For renaming Folder name

#Site Relative URL 
$FolderNewName ="FolderName" 

#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin

#Rename the Folder 
Rename-PnPFolder -Folder $LibURL -TargetFolderName $FolderNewName


