﻿#Config Variables 
$SiteURL = "#################" 
#$LibURL= "LibName/" #For renaming Lib name
$FolderURL= "LibName/FolderName" #For renaming Folder name

#Site Relative URL 
$FolderNewName ="LibName" 

#Connect to PnP Online 
Connect-PnPOnline -Url $SiteURL -UseWebLogin

#Rename the Folder
Rename-PnPFolder -Folder $FolderURL -TargetFolderName $FolderNewName

