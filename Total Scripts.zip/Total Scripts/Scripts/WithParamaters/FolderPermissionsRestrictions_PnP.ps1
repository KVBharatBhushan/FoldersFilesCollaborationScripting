﻿#Config Variables
$SiteURL = "###################"
$ListName="LibName"
$FolderServerRelativeURL = "/####/####/#####/LibName/FolderName"
  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin
 
#Set folder permissions - Add User
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -User "suresh.gade@sony.com" -AddRole "Full Control"
 
#To remove user, use: Set-PnPfolderPermission -List $ListName -identity $FolderSiteRelativePath -User "abcd.onmicrosoft.com" -RemoveRole "Edit"


