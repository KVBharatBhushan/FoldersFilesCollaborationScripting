﻿#Config Variables
$SiteURL = "#########################3"
$ListName="##############"
$FolderServerRelativeURL = "/####/####/#####/######/FolderName"



$foldercount=$($args.count)

write-host "There are a total of $($args.count) arguments" 

  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -Useweblogin
 
#Get the Folder from URL
$Folder = Get-PnPFolder -Url $FolderServerRelativeURL
     
      For($i = 0; $i -lt $args.count; $i++)
    {
        #Replace Invalid Characters from Folder Name, If any
        $UserAccount = $($args[$i])
        write-host  $FolderName
        
#Set Permission to Folder
Set-PnPListItemPermission -List $ListName -Identity $Folder.ListItemAllFields -User $UserAccount -AddRole 'Contribute'
   
  
}

    