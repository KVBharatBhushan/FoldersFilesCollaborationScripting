﻿#Config Variables
$SiteURL = "#####################"
$ListName="############"
$FolderServerRelativeURL = "/#####/#######/#########/##########/FolderName"


$foldercount=$($args.count)

write-host "There are a total of $($args.count) arguments" 
  
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -UseWebLogin

 For($i = 0; $i -lt $args.count; $i++)
    {
#To remove user, use:- -RemoveRole
$UserAccount = $($args[$i])
Set-PnPfolderPermission -List $ListName -identity $FolderServerRelativeURL -User $UserAccount -RemoveRole "Contribute"
}