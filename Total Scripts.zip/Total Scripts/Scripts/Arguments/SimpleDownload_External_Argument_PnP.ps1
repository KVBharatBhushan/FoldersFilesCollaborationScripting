﻿$SharePointSiteURL = "########################"  
# Change this SharePoint Site URL  
#$SharedDriveFolderPath = "D:\PnPInput\DemoLibFiles4" 
$SharedDriveFolderPath = $args[0]
 
# Change this Network Folder path  
#$SharePointFolderPath = "/LibName/FolderName" 
$SharePointFolderPath = $args[1]
  

Connect-PnPOnline -Url $SharePointSiteURL -UseWebLogin
  
$Files = Get-PnPFolderItem -FolderSiteRelativeUrl $SharePointFolderPath -ItemType File  
foreach($File in $Files) {  
    Get-PnPFile -Url $File.ServerRelativeUrl -Path $SharedDriveFolderPath -FileName $File.Name -AsFile 
    
    
}   