﻿#md FilePath

#cd FilePath

#Only run in the cmd prompt
Fsutil file createnew dummyfile1.pdf 2000000

Fsutil file createnew dummyfile2.doc 2000000

Fsutil file createnew dummyfile3.ppt 2000000

Fsutil file createnew dummyfile4.dat 2000000

#Use Upload Script to Upload onto the Lib