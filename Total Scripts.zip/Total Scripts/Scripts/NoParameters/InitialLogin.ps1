﻿

$SharePointSiteURL = "#################"  

Connect-PnPOnline -Url $SharePointSiteURL -UseWebLogin