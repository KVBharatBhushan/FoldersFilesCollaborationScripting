﻿Write-Host "Hello World!";

Write-Host "Invoking or Calling another PnP PS Script";

#D:\PnPInput\FolderManagement\Scripts\WithParamaters\CreateFolder_PnP.ps1 'Extra Folderzzz' '/Reports Archive'

D:\PnPInput\FolderManagement\Scripts\WithParamaters\CreateFolder_PnP.ps1


